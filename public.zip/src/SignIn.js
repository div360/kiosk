import React from "react";
// import './signIn.css'

export default function SignIn(){
    return(
        <>
        <div className="container">
        <input type="number" label="Enter ERP Number" />
        <button>Sign In</button>
        </div>
        </>
    )
}