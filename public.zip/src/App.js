
import './App.css';
import Otp from './Otp/Otp';
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
import SignIn from './SignIn';


function App() {
  return (
    <>
    <Router>
    <Routes>
    <Route exact path="/" element={<SignIn/>} />
    <Route exact path="/otp" element={<Otp/>}/>
    </Routes>
    </Router>
    </>
  );
}

export default App;
